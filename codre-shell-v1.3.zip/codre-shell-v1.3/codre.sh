#!/bin/bash

# Codre Shell | Version 1.3
# (c) Buck Runeway Kentach

VERSION="1.3"
CONTROL_DIR="$HOME"
HIST=()

# ---- Colors (soft & readable) ----
C_RESET="\e[0m"
C_MAIN="\e[38;5;81m"
C_ACCENT="\e[38;5;213m"
C_WARN="\e[38;5;203m"
C_OK="\e[38;5;114m"

# ---- Welcome ----
clear
echo -e "${C_MAIN}Codre Shell${C_RESET} | Version ${C_ACCENT}$VERSION${C_RESET}"
echo "(c) Buck Runeway Kentach"
echo
echo "Type help to get started."
echo

# ---- Prompt ----
print_prompt() {
  echo -ne "${C_ACCENT}codre${C_RESET}:${C_MAIN}$CONTROL_DIR${C_RESET}> "
}

# ---- Help ----
show_help() {
cat << EOF
Core:
  help                  Show help
  echo <text>           Print text
  time                  Date & time
  clr                   Clear screen
  exit                  Exit shell
  hist                  History
  about                 Information about Codre
  check <cmd>           Check if a bash command exists

Files:
  cont <dir>            Set control directory
  df                    Disk usage
  pwd                   Show control directory
  dir                   List files
  copy <a> <b>          Copy
  move <a> <b>          Move
  del <file>            Delete (safe)
  ren <a> <b>           Rename
  find <text>           Find files

Utilities:
  calc <expr>           Calculator
  noto <file>           Open nano
  neko                  System info
  sleep <sec>           Pause
  wink <len>            Random string
  who                   Current user info
  runa <cmd>            Run a bash command (sudo)
  wave <file>           Audio file info

Important: Codre shell is integrated into the Bash, with simplified interface. Bash commands work purely inside of Codre.
  (Simply: This shell is Bash+Codre)
EOF
}

# ---- Main loop ----
while true; do
  print_prompt
  read -r input
  HIST+=("$input")

  cmd=$(awk '{print $1}' <<< "$input")
  args=$(cut -d' ' -f2- <<< "$input")

  case "$cmd" in

    help)
      show_help
      ;;

    echo)
      echo "$args"
      ;;

    time)
      date
      ;;

    clr)
      clear
      ;;

    exit)
      echo -e "${C_ACCENT}Leaving Codre Shell…${C_RESET}"
      break
      ;;

    hist)
      for i in "${!HIST[@]}"; do
        echo "$i: ${HIST[$i]}"
      done
      ;;

    about)
      echo "Codre Shell | Version $VERSION"
      echo "(c) Buck Runeway Kentach"
      echo "Control directory: $CONTROL_DIR"
      ;;

    check)
      if command -v "$args" >/dev/null 2>&1; then
        echo -e "${C_OK}✓ '$args' is available${C_RESET}"
      else
        echo -e "${C_WARN}✗ '$args' not found${C_RESET}"
      fi
      ;;

    cont)
      if [ -d "$args" ]; then
        CONTROL_DIR=$(realpath "$args")
        echo -e "${C_OK}Control directory set${C_RESET}"
      else
        echo -e "${C_WARN}Directory not found${C_RESET}"
      fi
      ;;

    df)
      df -h
      ;;

    pwd)
      echo "$CONTROL_DIR"
      ;;

    dir)
      ls "$CONTROL_DIR"
      ;;

    copy)
      cp $args 2>/dev/null || echo -e "${C_WARN}Copy failed${C_RESET}"
      ;;

    move)
      mv $args 2>/dev/null || echo -e "${C_WARN}Move failed${C_RESET}"
      ;;

    del)
      rm -i "$args"
      ;;

    ren)
      set -- $args
      mv "$1" "$2" 2>/dev/null || echo -e "${C_WARN}Rename failed${C_RESET}"
      ;;

    find)
      find "$CONTROL_DIR" -iname "*$args*" 2>/dev/null
      ;;

    calc)
      echo "$args" | bc 2>/dev/null || echo "Invalid expression"
      ;;

    noto)
      nano "$args"
      ;;

    neko)
      uname -a
      ;;

    sleep)
      sleep "$args"
      ;;

    wink)
      len="${args:-8}"
      tr -dc 'a-zA-Z0-9' </dev/urandom | head -c "$len"
      echo
      ;;

    who)
      echo "User: $(whoami)"
      echo "Home: $HOME"
      echo "Shell: Codre"
      ;;

    runa)
      echo "Requesting elevated permissions…"
      sudo bash -c "$args"
      ;;

    wave)
      if command -v ffprobe >/dev/null 2>&1; then
        ffprobe -v error -show_format -show_streams "$args"
      else
        echo "ffprobe not installed"
      fi
      ;;

    "")
      ;;

    *)
      cd "$CONTROL_DIR" || exit
      bash -c "$input"
      ;;
  esac
done

