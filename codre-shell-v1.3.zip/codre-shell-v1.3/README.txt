Codre Shell v1.3
A lightweight, friendly shell playground. The shell is an experiment, where Codre is integrated into bash, with lightweight improvement and tools
Owner and editor of the shell: Buck Runeway Kentach, does provide the copyright license under the following condition: Attribution: Do not attribute this shell to yourself or anyone else than Buck RK.

Requirements:
- Linux/macOS
-- bash

Move codre.sh in your user folder;

Run:
chmod +x codre.sh
./codre.sh

Or, after integrating, run `codre` inside of bash.
